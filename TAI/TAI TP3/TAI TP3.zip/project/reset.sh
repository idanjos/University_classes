#!/bin/bash

rm -rf bin int config && rm -f Makefile
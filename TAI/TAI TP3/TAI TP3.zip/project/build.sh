#!/bin/bash

./vendor/premake/premake.sh && make
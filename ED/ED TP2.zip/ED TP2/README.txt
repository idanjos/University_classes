##HOW TO RUN##

	python project.py

##Jupyter##

	jupyter notebook

Then search for project.ipynb
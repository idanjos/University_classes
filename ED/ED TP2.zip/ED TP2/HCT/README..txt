Folder with 5 excel files

All files have the features collected into 26 EEG channels.
Column A: ID of the trial
Column B: Sub-test number
Column C: Number of participants giving correct or wrong answer for the trial.


1- datase_Trial_Time_Feedback. Time features collected after feedback.



2- datase_Trial_Time_Resposta.Time features collected after feedback.


3-dataset_Frequencia_Before_Resposta. Frequency features collected before the answer

4- dataset_Frequencia_Feedback. Frequency features collected after the feedback.

5-dataset_Frequencia_Resposta. Frequency features collected after the answer.  


NaN not a number means not available.
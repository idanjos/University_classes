import classifier
from sklearn.decomposition import KernelPCA


def main():
    Xtoy = []
    Ytoy = []
    with open("HCT/dataset.csv") as f:
        for line in f:
            temp = line.strip().split(",")
            if temp[0] == '1':
                Ytoy += [1]
            else:
                Ytoy += [0]
            temp2 = []
            for obj in temp[1:]:
                if "NaN" not in obj:
                    temp2 += [float(obj)]
                else:
                    temp2 += [0]
            Xtoy += [temp2]

    # c = classifier.Classifier(Xtoy,Ytoy)
    c = classifier.Classifier(Xtoy, Ytoy,
                              pca=KernelPCA(n_components=2, kernel='rbf', gamma=15, fit_inverse_transform=True))
    c.displayDataset()
    print(c.getSquaredError())
    print("SVC Linear")
    print(c.svcLinear())
    c.plot_decision_regions("svclinear")
    print("SVC Kernel RBF")
    print(c.svcKernel(kernel="rbf"))
    c.plot_decision_regions("svcKernel")
    print("Multi-layer Perceptron")
    print(c.Mlp())
    c.plot_decision_regions("mlp")
    print("Random Forest")
    print(c.randomForest2())
    c.plot_decision_regions("randomforest")
    print("Gradiant Boosting Classifier")
    print(c.GBR())
    c.plot_decision_regions("gradiantBoosting")
    print("XGBoost")
    print(c.xgBoost())
    c.plot_decision_regions("xgBoost")


if __name__ == "__main__":
    main()

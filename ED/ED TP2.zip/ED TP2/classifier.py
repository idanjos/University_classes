import matplotlib.pyplot as plt
import numpy as np
import xgboost as xgb
from matplotlib.colors import ListedColormap
from numpy import linalg as LA
from scipy import stats
from sklearn.decomposition import PCA
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold
from sklearn.model_selection import RandomizedSearchCV
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import LinearSVC
from sklearn.svm import SVC


class Classifier:

    # Constructor
    def __init__(self, dataset, labels, ntest=20, pca=None):
        # Variables
        self.Xtoy = dataset
        self.Ytoy = labels
        self.Xtest = []
        self.Ytest = []
        self.mlp = 0
        self.svc = 0
        self.svclinear = 0
        self.randomforest = 0
        self.gradiantBoosting = 0
        self.xgb = 0
        self.pca = None
        self.ntest = ntest
        self.scaler = MinMaxScaler()

        # PCA Initializer
        if pca is None:
            self.pca = PCA(n_components=2)
        else:
            self.pca = pca

        self.dataset = self.scaler.fit_transform(np.asarray(self.Xtoy))
        self.Xtoy = list(self.pca.fit_transform(self.dataset))

        # Cutting out test samples
        self.Xtest = self.Xtoy[:ntest]
        self.Ytest = self.Ytoy[:ntest]
        self.Xtoy = self.Xtoy[ntest:]
        self.Ytoy = self.Ytoy[ntest:]
        self.Xtest += self.Xtoy[len(self.Xtoy) - ntest:]
        self.Ytest += self.Ytoy[len(self.Ytoy) - ntest:]
        self.Xtoy = self.Xtoy[:len(self.Xtoy) - ntest]
        self.Ytoy = self.Ytoy[:len(self.Ytoy) - ntest]

        # Transforming them into numpy arrays
        self.Xtoy = np.asarray(self.Xtoy)
        self.Ytoy = np.asarray(self.Ytoy)

    # Display dataset
    def displayDataset(self, resolution=0.02):
        X = self.Xtoy
        y = self.Ytoy
        markers = ('o', 'x', 's', '^', 'v')
        colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
        cmap = ListedColormap(colors[:len(np.unique(y))])
        x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
        x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
        xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                               np.arange(x2_min, x2_max, resolution))

        plt.xlim(xx1.min(), xx1.max())
        plt.ylim(xx2.min(), xx2.max())
        # plot class samples
        for idx, cl in enumerate(np.unique(y)):
            plt.scatter(x=X[y == cl, 0], y=X[y == cl, 1],
                        alpha=0.8, c=cmap(idx), marker=markers[idx], label=cl)
        plt.legend(loc='upper left', borderaxespad=0.)

        plt.show()

    # Return Squared Error of the dataset
    def getSquaredError(self):
        X1 = self.pca.inverse_transform(self.Xtoy)
        a = self.dataset[self.ntest:(len(self.dataset) - self.ntest)] - X1
        return LA.norm(a)

    # SVC Linear Classifier
    def svcLinear(self, svm=None):
        # Initializer
        if svm == None:
            svm1 = LinearSVC(C=3.0, max_iter=1000, tol=1e-05, verbose=0)
        else:
            svm1 = svm

        svm1 = svm1.fit(self.Xtoy, self.Ytoy)
        results = svm1.predict(self.Xtest)

        # Calculating Accuracy
        accuracy = 0
        for i in range(0, len(self.Ytest)):
            if self.Ytest[i] == results[i]:
                accuracy += 1
        self.svclinear = svm1
        return accuracy / len(self.Ytest)

    # SVC Kernel Classifier
    def svcKernel(self, svm=None, kernel='linear'):
        # Initializer
        if svm is None:
            svm1 = SVC(C=1.0, kernel=kernel, max_iter=1000, tol=1e-05, verbose=0, gamma='scale')
        else:
            svm1 = svm

        svm1 = svm1.fit(self.Xtoy, self.Ytoy)
        results = svm1.predict(self.Xtest)

        # Calculating Accuracy
        accuracy = 0
        for i in range(0, len(self.Ytest)):
            if self.Ytest[i] == results[i]:
                accuracy += 1
        self.svc = svm1
        return accuracy / len(self.Ytest)

    # Multi-layer Preceptron Classifier
    def Mlp(self, mlp1=None):
        # Initializer
        mlp = mlp1
        if mlp1 is None:
            mlp = MLPClassifier(activation='tanh', hidden_layer_sizes=(10, 5), alpha=0.01, max_iter=5000)

        mlp.fit(self.Xtoy, self.Ytoy)
        results = mlp.predict(self.Xtest)

        # Calculating Accuracy
        accuracy = 0
        for i in range(0, len(self.Ytest)):
            if self.Ytest[i] == results[i]:
                accuracy += 1
        self.mlp = mlp
        return accuracy / len(self.Ytest)

    # Random Forest Classifier
    def randomForest(self, r1=None):
        # Initializer
        forest = r1
        if r1 is None:
            forest = RandomForestClassifier(max_depth=3, min_samples_split=5, n_estimators=10, max_features='log2',
                                            oob_score=False)

        forest = forest.fit(self.Xtoy, self.Ytoy)
        results = forest.predict(self.Xtest)

        # Calculating Accuracy
        accuracy = 0
        for i in range(0, len(self.Ytest)):
            if self.Ytest[i] == results[i]:
                accuracy += 1
        self.randomforest = forest
        return accuracy / len(self.Ytest)

    def randomForest2(self):

        forest = RandomForestClassifier(max_depth=3, min_samples_split=5, n_estimators=10, max_features='log2',
                                        oob_score=False)
        param_dist = {"max_depth": [3, 4, 5, 6, 7, 8, None],
                      "max_features": ['auto', 'sqrt', 'log2'],
                      "min_samples_split": stats.randint(2, 11),
                      "bootstrap": [True, False],
                      "n_estimators": stats.randint(100, 1000)}

        kfold10 = KFold(n_splits=5, shuffle=True)

        clf = RandomizedSearchCV(forest,
                                 param_distributions=param_dist,
                                 cv=kfold10,
                                 n_iter=5,
                                 scoring='roc_auc',
                                 error_score=0,
                                 verbose=3,
                                 n_jobs=-1)
        clf.fit(self.Xtoy, self.Ytoy)
        score = clf.score(self.Xtest, self.Ytest)
        self.randomforest = clf
        return score

    # Gradiant Boosting Regressor Classifier
    def GBR(self):
        # Initializer
        gbr = GradientBoostingClassifier(max_depth=3, n_estimators=100, random_state=2)

        param_dist = {'n_estimators': stats.randint(150, 1000),
                      'learning_rate': stats.uniform(0.01, 0.9),
                      'subsample': stats.uniform(0.3, 0.9),
                      'max_depth': [3, 4, 5, 6, 7, 8, 9]
                      }

        kfold10 = KFold(n_splits=10, shuffle=True)

        clf = RandomizedSearchCV(gbr,
                                 param_distributions=param_dist,
                                 cv=kfold10,
                                 n_iter=10,
                                 scoring='roc_auc',
                                 error_score=0,
                                 verbose=3,
                                 n_jobs=-1)
        clf.fit(self.Xtoy, self.Ytoy)
        score = clf.score(self.Xtest, self.Ytest)
        self.gradiantBoosting = clf
        return score


    def xgBoost(self):
        # Initializer
        clf_xgb = xgb.XGBClassifier()
        param_dist = {'n_estimators': stats.randint(150, 1000),
                      'learning_rate': stats.uniform(0.01, 0.6),
                      'subsample': stats.uniform(0.3, 0.8),
                      'max_depth': [3, 4, 5, 6, 7, 8, 9],
                      'colsample_bytree': stats.uniform(0.3, 0.9),
                      'min_child_weight': [1, 2, 3, 4]
                      }

        kfold10 = KFold(n_splits=10, shuffle=True)

        clf = RandomizedSearchCV(clf_xgb,
                                 param_distributions=param_dist,
                                 cv=kfold10,
                                 n_iter=10,
                                 scoring='roc_auc',
                                 error_score=0,
                                 verbose=3,
                                 n_jobs=-1)
        clf.fit(self.Xtoy, self.Ytoy)
        score = clf.score(self.Xtest, self.Ytest)
        self.xgb = clf
        return score

    # Plot Decision Regions
    def plot_decision_regions(self, classifier, resolution=0.02):

        # Retrieving the classifier selected
        if classifier == "svcKernel":
            classifier = self.svc
        if classifier == "svclinear":
            classifier = self.svclinear
        if classifier == "mlp":
            classifier = self.mlp
        if classifier == "randomforest":
            classifier = self.randomforest
        if classifier == "gradiantBoosting":
            classifier = self.gradiantBoosting
        if classifier == "xgBoost":
            classifier = self.xgb

        # Error if its not initialized
        if classifier == 0:
            print("Failed to project empty classifier")
            return

        # Variables
        X = self.Xtoy
        y = self.Ytoy
        markers = ('o', 'x', 's', '^', 'v')
        colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
        cmap = ListedColormap(colors[:len(np.unique(y))])
        x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
        x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
        xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                               np.arange(x2_min, x2_max, resolution))
        Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
        Z = Z.reshape(xx1.shape)

        plt.contourf(xx1, xx2, Z, alpha=0.4, cmap=cmap)
        plt.xlim(xx1.min(), xx1.max())
        plt.ylim(xx2.min(), xx2.max())

        # plot class samples
        for idx, cl in enumerate(np.unique(y)):
            plt.scatter(x=X[y == cl, 0], y=X[y == cl, 1],
                        alpha=0.8, c=cmap(idx), marker=markers[idx], label=cl)
        plt.legend(loc='upper left', borderaxespad=0.)

        plt.show()

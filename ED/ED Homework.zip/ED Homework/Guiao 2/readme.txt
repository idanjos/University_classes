- Mudar o nome do connection manager deti-sql-aulas.ua.pt.moreira -> os alunos v�o ter que usar as suas credenciais.
- Limpar as conex�es que n�o s�o necess�rias.
- Ver as convers�es do campo description
- Ver caminhos absolutos: country codes


import segments
import taxisgps
import random
import pprint
import gc
import math


import matplotlib.pyplot as plt
# TODO, input Date queries
def loadTaxisGPS(filename):
	output = []
	with open(filename,'r') as f:
		for line in f:
			temp = line.replace('\n',"").split('\t')
			#print(line.replace('\n',"").split('\t'))
			output += [taxisgps.TaxisGPS(temp[0],temp[1],temp[2],temp[3],temp[4],temp[5],temp[6])]
	return output


def loadSegments(filename):
	output = {}
	with open(filename,'r') as f:
		for line in f:
			temp = line.replace('\n',"").split('\t')
			#print(line.replace('\n',"").split('\t'))
			output[temp[0]] = segments.Segment(int(temp[0]),temp[1],int(temp[2]),int(temp[3]),int(temp[4]),temp[5])
	return output

def loadTaxis(array,day=2):
	output = {}
	lastDate = "" 
	for record in array:
		if record.getTaxiId() not in output.keys():
			taxi = taxisgps.Taxi(record.getTaxiId())
			taxi.addRecord(record.getRecord())
			output[record.getTaxiId()] = taxi
		else:


			if "2008-02-0"+str(day) in record.getRecord()[3]:
				output[record.getTaxiId()].addRecord(record.getRecord())
				#print("2008-02-0"+str(day))
			
	return output

def newSegments(segmentsRecords,taxisgps):
	
	for gps in taxisgps:
		if gps.getSegmentId() in segmentsRecords.keys():
			segmentsRecords[gps.getSegmentId()].addCoords(gps.getCoords())
		else:
			pass
			#print(gps.getSegmentId())
			#segmentsRecords[gps.getSegmentId()] = segments.Segment(None,gps.getSegmentId(),0,0,0,"unclassified")
			#segmentsRecords[gps.getSegmentId()].addCoords(gps.getCoords())

def createMap(segms):
	x = []
	y = []
	c = []
	# for key in segms.keys():
	# 	color = random.randint(50,200)
	# 	for coord in segms[key].getCoords():
	# 		x += [float(coord[1])]
	# 		y += [float(coord[0])]
	# 		c += [color]
	data = {}
	data['x'] = x
	data['y'] = y
	data['c'] = c
	return data

def dist2(p1, p2):
    return math.sqrt((float(p1[2])-float(p2[2]))**2 + (float(p1[1])-float(p2[1]))**2)

def timeDiff(d1,d2): # returns Seconds

	if d1.split(" ")[0] != d2.split(" ")[0]:
		return 82400 

	t1 = d1.split(" ")[1]
	t2 = d2.split(" ")[1]

	s1 = int(t1.split(":")[0])*60*60 + int(t1.split(":")[1])*60 + int(t1.split(":")[2])
	s2 = int(t2.split(":")[0])*60*60 + int(t2.split(":")[1])*60 + int(t2.split(":")[2])
	#print(s1,s2)
	return math.sqrt((s1-s2)**2)


def removeFarness(array):
	threshold = 0.00000001
	flag = 0
	output = []
	#print(array)
	if len(array) < 2:
		return output
	for pivot in array:
		pivot_points = []
		if pivot in output:
			continue
		for point in array:
			if point in pivot_points:
				continue
			if pivot != point:
				if dist2(pivot,point) < threshold:
					#print(timeDiff(pivot[3],point[3]))
					#print(pivot)
					#print(point)
					if timeDiff(pivot[3],point[3]) > 120:
						flag += 1
						#pivot_points += [point]
						break
		if flag >= 5:
			output+=[pivot]+pivot_points
			flag = 0
	#print(output)		
	return output
	

def showTaxi(data,taxi,i,road):

	color = random.randint(0,100)
	array = removeFarness(taxi.getRecords())
	
	for coords in array:
		if coords[0] not in road.keys():
			road[coords[0]]=1
		else:
			road[coords[0]]+=1

	for coords in array:
		if road[coords[0]] >= 5:
			data['x'] += [float(coords[2])]
			data['y'] += [float(coords[1])]
			data['c'] += [color]
		
	


def main():
	segments_collection = loadSegments("my_road_segments.txt")
	taxisgps_collection = loadTaxisGPS("my_taxisgps.txt")
	newSegments(segments_collection,taxisgps_collection)
	data = {}
	road = {}
	plt.figure(1)
	for i in range(2,8):
		
		taxis = loadTaxis(taxisgps_collection,i)
		#for record in taxis["1"].getRecords():
		#	print(record)
		#print(len(taxis.keys()))
		#print(segments_collection['7277'])
		data = createMap(segments_collection)
		for key in taxis.keys():
			showTaxi(data,taxis[key],i-2,road)	
		#showTaxi(data,taxis["2"],i-2)
		#print(data['x'][-1])
		plt.subplot(3,2,i-1)
		plt.scatter(data['x'],data['y'],c=data['c'],)

		plt.xlabel('Latitude')
		plt.ylabel('Longitude')
		del data
		gc.collect()
	plt.figure(2)
	x = []
	y = []
	for key in road.keys():
		if road[key] >= 12:
			x +=[key]
			y+=[road[key]]
			#print(key)
	plt.barh(x,y)
	plt.yticks(x,x)
	plt.show()	
main()
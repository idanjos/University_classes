'''
	gid: identificação do segmento;
    osm_id: identificação da estrada correspondente no Open Street Maps
    oneway: estrada com um ou dois sentidos
    bridge: indica se é ou não uma ponte
    tunnel: indica se é ou não um túnel
    type: tipo de estrada (primária, terciária, pedonal, etc.)
'''

class Segment():
	def __init__(self,gid,osm_id,oneway,bridge,tunnel,type_road):
		self.gid 		= 	gid
		self.osm_id 	= 	osm_id
		self.oneway 	= 	oneway
		self.bridge 	= 	bridge
		self.tunnel 	= 	tunnel
		self.type_road	=	type_road
		self.coords 	=	[]			#Tuple (lon,lat)
	def __str__ (self):
		return str(self.coords)
	def __repr__(self):
		return self.coords
	def addCoords(self,location):
		self.coords += [location]
	def getCoords(self):
		return self.coords
	#functions...


'''
	gid: número sequencial
    obsid: identificação da amostra nos dados originais (T-drive dataset)
    taxiid: identificação do táxi
    segmentid: identificação do segmento de estrada onde estava o táxi
    lon: longitude (coordenada original - antes do map-matching
    lat: latitude (coordenada original - antes do map-matching
    dateobs: data e hora da amostra
'''
class TaxisGPS():
	def __init__(self,gid,obsid,taxiid,segmentid,lon,lat,dateobs):
		self.gid 		= 	gid
		self.obsid		=	obsid
		self.taxiid		=	taxiid
		self.segmentid	=	segmentid
		self.lon 		=	lon
		self.lat 		= 	lat
		self.dateobs	= 	dateobs
	def __repr__(self):
		return self.gid
	def getTaxiId(self):
		return self.taxiid
	def getSegmentId(self):
		return self.segmentid
	def getCoords(self):
		return (self.lon,self.lat)
	def getRecord(self):
		return (self.segmentid,self.lon,self.lat,self.dateobs)
	#functions ...

class Taxi():
	def __init__(self,idd):
		self.id 		= 	idd
		self.records 	=	[]
	def addRecord(self,record):
		self.records += [record]
	def printRecords(self):
		print(self.records)
	def getRecords(self):
		return self.records
	def lastRecord(self):
		return self.records[-1]
	def __repr__(self):
		return self.records
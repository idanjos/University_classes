import redis

r = redis.Redis(
    host='localhost',
    port=6379, 
    password='')

r.flushdb()

class AutoComplete:
	def __init__(self,redis):
		self.r = redis
		

	def getResults(self,string):
		return self.r.keys("*"+string+"*")


def main():
	with open("female-names.txt", "r") as ins:
		for line in ins:
			r.lpush(line, line)
	stdin = input('Insert name: ')
	ac = AutoComplete(r)
	for result in ac.getResults(stdin):
		print(str(result).strip('b\'\n\r\t\\n'))

main()
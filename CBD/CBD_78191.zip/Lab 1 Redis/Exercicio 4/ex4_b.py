
import csv
import redis

r = redis.Redis(
    host='localhost',
    port=6379, 
    password='')

r.flushdb()

class AutoComplete:
	def __init__(self,redis):
		self.r = redis
		

	def getResults(self,string):
		return self.r.keys("*"+string+"*")

	def getPopularResults(self,string):
		diict = dict()
		for key in self.r.keys("*"+string+"*"):
			diict[str(key).strip('b\'')]=int(str(r.get(key)).strip('b\''))
		return diict
def main():
	with open('nomes-registados-2016.csv', mode='r') as infile:
	    reader = csv.reader(infile)
	    for row in reader:
	    	r.append(row[0],row[2])

	stdin = input('Insert name: ')
	ac = AutoComplete(r)
	diict = ac.getPopularResults(stdin)
	for x in sorted([(value,key) for (key,value) in diict.items()],reverse=True):
  		print("%s has %d entrie(s)" % (x[1],x[0]))
	
main()
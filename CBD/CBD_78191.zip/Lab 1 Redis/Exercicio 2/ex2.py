import redis

r = redis.Redis(
    host='localhost',
    port=6379, 
    password='')

r.flushdb()

with open("female-names.txt", "r") as ins:
	letter = ""
	for line in ins:
		if letter != line[0]:
			if letter != "":
				print("Letter %s has %d entries" % (letter,r.llen(letter)))

			letter = line[0]
        #print(line[0])
		r.lpush(line[0], line)
	print("Letter %s has %d entries" % (letter,r.llen(letter)))		
print("END")
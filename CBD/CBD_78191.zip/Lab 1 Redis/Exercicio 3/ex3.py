import redis

r = redis.Redis(
    host='localhost',
    port=6379, 
    password='')

r.flushdb()

def add_array():
	array = list()
	with open("female-names.txt", "r") as ins:
		for line in ins:
			array.append(line)
	r.rpush("names",*array)
	print("%d names added" % (r.llen("names")))


def add_dictionary():
	dictt = dict()
	with open("female-names.txt", "r") as ins:
		for line in ins:
			dictt[line]=line
	r.hmset("dict", dictt)

	print("HashMap has %d keys " % len(r.hgetall("dict").keys()))

add_array()
add_dictionary()


print("End")
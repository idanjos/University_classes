import redis

r = redis.Redis(
    host='localhost',
    port=6379, 
    password='')
r.flushdb()

class System:
	def __init__(self,redis):
		self.r = redis
		
	def add_user(self,name):
		if  self.r.exists(name)>0:
			print("Error: User %s already exists" % name)
			return
		info = dict()
		info["name"]=name
		info["following"]=""
		info["messages"]=""
		self.r.hmset(name,info)

	def createMessage(self,name):
		if  self.r.exists(name)<1:
			print("Error: User %s doesn't exist" % name)
			return
		messages = self.r.hmget(name,"messages")[0].decode("utf-8")
		new_message = input("Message?: ")
		if len(messages)<1:
			
			messages=new_message
		else:
			messages+=","+new_message
			#print(messages)

		self.r.hmset(name,{"messages":messages})
		print("Success!")

	def addFollower(self,name):
		if  self.r.exists(name)<1:
			print("Error: User %s doesn't exist" % name)
			return

		follow = input("Following?: ")

		if  self.r.exists(follow)<1:
			print("Error: User %s doesn't exist" % follow)
			return
		follows = self.r.hmget(name,"following")[0].decode("utf-8")
		if len(follows)<1:
			
			follows=follow
		else:
			follows+=","+follow

		self.r.hmset(name,{"following":follows})
		print("User %s is following %s!" % (name,follow))

	def printUserFeed(self,name):
		follows = self.r.hmget(name,"following")[0].decode("utf-8")
		for follow in follows.split(","):
			messages = self.r.hmget(follow,"messages")[0].decode("utf-8")
			for message in messages.split(","):
				print("User %s said %s" % (follow,message))
		

	def printDatabase(self):
		output = dict()
		for key in self.r.keys("*"):
			output[key]=self.r.hgetall(key)
		print(output)
def main():
	while(True):
		system = System(r)
		stdin = input("1) Add user\n2) Print Database\n3) Create a message\n4) Following\n5) Show Feed\n0) Exit\nOption: ")
		if stdin == "0":
			return
		if stdin == "1":
			user = input("User's name: ")
			system.add_user(user)
		if stdin == "2":
			system.printDatabase()
		if stdin == "3":
			user = input("User's name: ")
			system.createMessage(user)
		if stdin == "4":
			user = input("User's name: ")
			system.addFollower(user)
		if stdin == "5":
			user = input("User's name: ")
			system.printUserFeed(user)

main()


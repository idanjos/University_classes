findpattern = function(pattern){
	
	print(db.phones.find({"component.display":{$regex:pattern}}).forEach(printjson));
	
}
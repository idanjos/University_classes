import pymongo
import os
import json


#print(myclient.list_database_names())


class MongoCollection():
	def __init__(self,collection):
		self.col = collection
	def find(self,query,options={}):
		return self.col.find(query,options)
	def update(self,doc,value):
		try:
			self.col.update_many(doc,value)
			print("Success!")
		except Exception as e:
			print(e)
	def delete(self,doc):
		try:
			print("%d documents deleted" % (self.col.delete_many(doc).deleted_count))
		except Exception as e:
			print("Failed to delete!")
			print(e)
	def insert(self,doc):
		try:
			if isinstance(doc,list):
				self.col.insert_many(doc)
			else:
				self.col.insert_one(doc)
		except Exception as e:
			print("Failed to insert")
			return
		print("Success!")
	def aggregate(self,doc_list):
		try:
			return self.col.aggregate(doc_list)
		except Exception as e:
			raise e
	def countLocalidades(self):
		i = 0
		query = [{"$group" : {'_id':"$localidade", 'count':{'$sum':1}}}]

		for row in self.aggregate(query):
			i+=1
		print(i)

	def countRestByLocalidade(self):
		query = [{"$group" : {'_id':"$localidade", 'count':{'$sum':1}}}]

		for row in self.aggregate(query):
			print(row)
	def countRestByLocalidadeByGastronomia(self):
		pass
	def getRestWithNameCloserTo(self,name):
		for doc in self.find({'nome':{'$regex':name}}):
			print(doc)
	def find2_2(self,query={},options={},limit=-1,skip=-1):
		if limit>-1:
			if skip>-1:
				for doc in self.find(query,options).limit(limit).skip(skip):
					print(doc)
			else:
				for doc in self.find(query,options).limit(limit):
					print(doc)
			
		else:
			for doc in self.find(query,options):
				print(doc)

		print("-----------------------")
def main():
	try:
		myclient = pymongo.MongoClient("mongodb://localhost:27017")
		mydb = myclient["cbd"]
		mycol = mydb["rest"]
		mongo = MongoCollection(mycol)
		print("Connected!")
	except Exception as e:
		print("Failed to connected!")
	while(True):
		
		stdin = input("1) Insert query\n2) Find query\n3) Update query\n4) Delete\n0) Exit and execute queries\nOption: ")
		os.system('clear')
		if stdin == "0":
			break
		if stdin == "1":
			stdin = input("Write a document: ")
			try:
				doc = json.loads(stdin)
				mongo.insert(doc)
			except Exception as e:
				doc = {'input': stdin}
				mongo.insert(doc)
				
		if stdin == "2":
			stdin = input("Write a document: ")
			try:
				doc = json.loads(stdin)
				for docu in mongo.find(doc):
					print (docu)
			except Exception as e:
				doc = {'input': stdin}
				for docu in mongo.find(doc):
					print (docu)
		if stdin == "3":
			stdin = input("Write a document: ")
			value = input("New value? ")
			try:
				doc = json.loads(stdin)
				value = json.loads(value)
				mongo.update(doc,value)
			except Exception as e:
				doc = {'input': stdin}
				value = {'$set': {'input': value}}
				mongo.update(doc,value)
		if stdin == "4":
			stdin = input("Write a document: ")
			try:
				doc = json.loads(stdin)
				mongo.delete(doc)
			except Exception as e:
				doc = {'input': stdin}
				mongo.delete(doc)
		if stdin == "5":
			user = input("Video's name: ")
			app.printFollowers(user)
	queries(mongo)
	q2_2(mongo)
def queries(mongo):
	mongo.countLocalidades()
	mongo.countRestByLocalidade()
	#Map<String, Integer> countRestByLocalidadeByGastronomia()
	mongo.getRestWithNameCloserTo('Park')

def q2_2(mongo):
	mongo.find2_2() #1
	mongo.find2_2({},{'restaurant_id':1,'nome':1,'localidade':1,'gastronomia':1}) #2
	mongo.find2_2({},{'restaurant_id':1,'nome':1,'localidade':1,"address.zipcode":1,'_id':0}) #3
	mongo.find2_2({'localidade':"Bronx"}) #4
	mongo.find2_2({'localidade':"Bronx"},{},5) #5
	mongo.find2_2({'localidade':"Bronx"},{},5,5) #6
	mongo.find2_2({"grades.score": {'$gt':85}}) #7
	mongo.find2_2({'$and':[{"grades.score": {'$gt':85}},{"grades.score": {'$lt':100}}]}) #8
	mongo.find2_2({'$and':[{"address.coord.0":{'$lt':-95}},{"address.coord.0":{'$lt':7}}]}) #9
	mongo.find2_2({'$and':[{'gastronomia':{'$ne': "American"}},{"grades.score":{'$gt':70}},{"address.coord.0":{'$lt':-65}}]}) #10
	mongo.find2_2({'nome':{'$regex':'Wil*'}},{'restaurant_id':1,'nome':1,'gastronomia':1}) #11
	mongo.find2_2({'nome':{'$regex':'[A-Za-z]*ces'}},{'restaurant_id':1,'nome':1,'gastronomia':1}) #12
	mongo.find2_2({'nome':{'$regex':"Park"}},{'nome':1,'localidade':1,'_id':0}) #13
	mongo.find2_2({'$or':[{'gastronomia':"American"},{'gastronomia':"Chinese"}]},{'nome':1,'localidade':1,'gastronomia':1,'_id':0}) #14
	mongo.find2_2({'$or':[{'localidade':"Staten Island"},{'localidade':"Queens"},{'localidade':"Bronx"},{'localidade':"Brooklyn"}]},{'restaurant_id':1,'nome':1,'localidade':1,'gastronomia':1,'_id':0}) #15
	mongo.find2_2({'$nor':[{'localidade':"Staten Island"},{'localidade':"Queens"},{'localidade':"Bronx"},{'localidade':"Brooklyn"}]},{'restaurant_id':1,'nome':1,'localidade':1,'gastronomia':1,'_id':0}) #16
	mongo.find2_2({"grades.score":{'$not':{'$gt': 3}}},{'_id':0,'nome':1,'localidade':1,"grades.score":1,'gastronomia':1}) #17
	mongo.find2_2({'$or':[{'$nor':[{'gastronomia':"American"},{'gastronomia':"Chinese"}]},{'nome':{'$regex':"Wil[A-Za-z]*"}}]},{'_id':0,'restaurant_id':1,'nome':1,'localidade':1,'gastronomia':1}) #18
	mongo.find2_2({'$and':[{"grades.date":{'$eq': 'ISODate("2014-08-11T00: 00: 00Z")'}},{"grades.score":10},{"grades.grade":"A"}]},{'_id':0,'nome':1,'grades':1}) #19
	mongo.find2_2({'$and':[{"grades.1.grade":"A"},{"grades.1.date":{'$eq': 'ISODate("2014-08-11T00: 00: 00Z")'}}]},{'_id':0,'restaurant_id':1,'nome':1,'grades':1}) #20

	mongo.find2_2({'$and':[{"address.coord.1":{'$gt':42}},{"address.coord.1":{'$lte':52}}]},{'_id':0,'restaurant_id':1,'nome':1,'address':1}) #21
	
	#22
	print("----------------")
	for doc in mongo.find({},{'_id':0,'nome':1}).sort('nome',1):
		print(doc)

	#23
	print("----------------")
	for doc in mongo.find({},{'_id':0,'nome':1}).sort('nome',-1):
		print(doc)
	#25
	print("----------------")
	for doc in mongo.find({},{'_id':0,'nome':1,'gastronomia':1,'localidade':1}).sort([['gastronomia',1],['localidade',-1]]):
		print(doc)
	#26
	print("----------------")
	for doc in mongo.find({'$and':[{'gastronomia':{'$not':{'$eq':"American"}}},{"grades.grade":"A"},{'localidade':"Brooklyn"}]},{'_id':0,'nome':1,'localidade':1,"grades.grade":1,'gastronomia':1}).sort('gastronomia',-1):
		print(doc)
	#27
	print("----------------")
	print(mongo.find({"address.rua":{'$exists': 'false'}}).count()) #27"
	
	mongo.countRestByLocalidade() #28


main()


package com.mycompany.cbd4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Transaction;
import org.neo4j.driver.v1.TransactionWork;

import static org.neo4j.driver.v1.Values.parameters;
// This project is using Movie-Graph example to experiment maven neo4j driver
public class HelloWorldExample implements AutoCloseable {

    private final Driver driver;

    public HelloWorldExample(String uri, String user, String password) {
        driver = GraphDatabase.driver(uri, AuthTokens.basic(user, password));
    }

    @Override
    public void close() throws Exception {
        driver.close();
    }

    
    public void execute(String query){
         try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    StatementResult result = tx.run(query);
                    while(result.hasNext())
                        System.out.println(result.next());
                   return "";
                }
            });
            System.out.println(greeting);
        }
    }

    public static void main(String... args) throws Exception {
        try (HelloWorldExample greeter = new HelloWorldExample("bolt://localhost:7687", "neo4j", "1")) {
            //greeter.printGreeting("hello, world");
           // greeter.execute("match (n) return n.name;");
            System.out.println("Connected!");
            String query = "";
            while(true){
                Scanner sc = new Scanner(System.in);
                query = sc.nextLine();
                if(query.contains("exit")){
                    System.out.println("Exitting");
                    break;
                }
                greeter.execute(query);
                    
            }
        }



    }
}

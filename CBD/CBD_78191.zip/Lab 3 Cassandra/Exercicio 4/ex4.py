import json
import random
import time
from cassandra.cluster import Cluster
import os


class Cassandra():
	def __init__(self,session):
		self.session = session

	def update(self):
		pass
	def read(self,cql,params=[]):
		return self.session.execute(cql,params)
	def insert(self,cql,params=[]):
		try:
			self.session.execute(cql,params)
			print("Success!")
		except Exception as e:
			print("Error")
		pass
	def delete(self,cql,params=[]):
		try:
			self.session.execute(cql,params)
			print("Success!")
		except Exception as e:
			print("Error")
		pass
	def test(self, table):
		pass
	def exec(self, string):
		try:
			self.session.execute(string)
			print("("+string+")->Success!")
		except Exception as e:
			print(e)
		
		#print("%d results" % (self.session.execute(string).count()))

class App():
	def __init__(self,driver):
		self.driver = driver # can only read update insert delete 
		self.driver.exec('use video_sharing')

	def addUser(self,user):
		cql = "INSERT INTO user (id, username, reg_date) VALUES (%s,%s,%s)"
		idd=random.randint(1000,9999)
		timestamp = int(time.time())
		self.driver.insert(cql,(idd,user,timestamp))
	def addVideo(self):
		pass
	def addEvent(self):
		pass
	def addComment(self):
		pass
	def addFollower(self):
		pass
	def addRating(self):
		pass

	def editUser(self,user):
		
		cql = "select id from user where username = '"+user+"' ALLOW FILTERING"
		try:
			u_id=str(self.driver.read(cql)[0]).split("=")[1].strip("\)")
			new_user = input("New username: ")
			cql = "update user set username = '"+new_user+"' where id = "+u_id
			self.driver.delete(cql)
		except:
			print("User not found")
	def editVideo(self):
		pass
	def editComment(self):
		pass

	def removeFollower(self):
		pass
	def removeRating(self):
		pass
	def removeVideo(self):
		pass
	def removeUser(self,user):
		cql = "select id from user where username = '"+user+"' ALLOW FILTERING"
		#print(cql)
		try:
			u_id=str(self.driver.read(cql)[0]).split("=")[1].strip("\)")
			cql = "delete from user where id = "+u_id
			self.driver.delete(cql)
		except:
			print("User not found!")
	def removeComment(self):
		pass

	def getUser(self):
		pass
	def getVideo(self):
		pass
	def getComments(self):
		pass
	def getFollowers(self):
		pass
	def getUsers(self):
		pass
	def getVideos(self):
		pass

	def printUsers(self):
		cql = "select * from user"
		for user in self.driver.read(cql):
			print(user)
		

	def printFollowers(self,video):
		cql = "select id from video where name = '"+video+"' ALLOW FILTERING"
		#print(cql)
		try:
			v_id=str(self.driver.read(cql)[0]).split("=")[1].strip("\)")
			cql = "select * from follower where video_id = "+v_id+" ALLOW FILTERING"
			print(cql)
			for row in self.driver.read(cql):
				print(row)
		except Exception as e:
			print("User not found")
		
		
		

def main():
	cluster = Cluster()
	try:
		session = cluster.connect()
		print("Connected!")
		cass = Cassandra(session)
		app = App(Cassandra(session))
	except:
		pass

	while(True):
		
		stdin = input("1) Add User\n2) List Users\n3) Edit User\n4) Remove User\n5) Show Followers\n0) Exit and execute 5 queries\nOption: ")
		os.system('clear')
		if stdin == "0":
			return
		if stdin == "1":
			user = input("User's name: ")
			app.addUser(user)
		if stdin == "2":
			app.printUsers()
		if stdin == "3":
			user = input("User's name: ")
			app.editUser(user)
		if stdin == "4":
			user = input("User's name: ")
			app.removeUser(user)	
		if stdin == "5":
			user = input("Video's name: ")
			app.printFollowers(user)
			
def five_queries():
	cluster = Cluster()
	try:
		session = cluster.connect('video_sharing')
		print("Connected!")
		
		
		#Todos os vídeos com a tag Aveiro;

		rows=session.execute("select * from video where tags CONTAINS 'Aveiro' ALLOW FILTERING")
		for row in rows:
			print(row)

		#Lista das tags de determinado vídeo;
		rows=session.execute("select name, tags from video where name = 'v1' ALLOW FILTERING")
		for row in rows:
			print(row)

		#Todos os seguidores (followers) de determinado vídeo;
		rows=session.execute("select video_id, user from follower where video_id = 2 ALLOW FILTERING")
		for row in rows:
			print(row)

	except:
		pass
#main()
five_queries()
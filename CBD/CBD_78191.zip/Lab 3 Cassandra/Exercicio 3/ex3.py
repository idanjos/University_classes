import json
from cassandra.cluster import Cluster

cluster = Cluster()
session = cluster.connect('restaurants')


def main():
	with open("restaurants.json") as json_file:
	    #json_data = json.load(json_file)
	    for r in json_file:
	    	d = json.loads(r)
	    	cql = "INSERT INTO restaurant (restaurant_id, address, gastronomia, grades, localidade , nome) VALUES (%s,%s,%s,%s,%s,%s)"
	    	address = d["address"]
	    	grades=d["grades"]
	    	address["coord"]=str(address["coord"])
	    	
	    	#print(d["grades"])
	    	for grade in grades:
	    		grade["date"]=str(grade["date"]["$date"])
	    		grade["score"]=str(grade["score"])
	    		#print(grade)
	    	
	    	session.execute(cql,  (int(d["restaurant_id"]), address, d["gastronomia"],grades, d["localidade"],d["nome"]))

rows = session.execute('select * from restaurant')
for row in rows:
	print(row)

main()
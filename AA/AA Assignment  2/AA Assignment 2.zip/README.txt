##2nd Assignment##


#How to use
python aa.py -h

#Interesting results are in the results folder.

Any questions related to this work contact:

Isaac dos Anjos
itda@ua.pt

import itertools
import time
class Graph:
	def __init__(self,matrix,CpuLimite=0,NSolutions=0):
		self.limitCpuTime = CpuLimite
		self.numSolutions = NSolutions
		self.matrix = matrix
		self.iters = 0
		self.bestSolution = 0
		self.solutions = set()
		self.n = len(matrix[0])
		self.combinations = [tuple(range(0,self.n))]
		self.bestNodes = self.getBestNode()
		pass
	def getBestNode(self):
		bestNode = []
		best = 0
		temp = 0
		for line in range(0,len(self.matrix)):
			temp = 0
			if best > (len(self.matrix)-(line+1)):
				break
			for cell in self.matrix[line]:
				if cell == 1:
					temp += 1
			if temp > best:
				best = temp
				bestNode = [line]
			elif temp == best:
				bestNode += [line]
		#print("Best nodes")
		#print(bestNode)
		return bestNode

		pass
	def loadPermutations(self):
		i = self.n-1
		while i >= 1:
			self.combinations += self.getCombinations(i)
			i-=1
	def getCombinations(self,n):
		if n>= self.n:
			return self.combinations
		temp = list(itertools.combinations(range(0,self.n),n))
		#print(output)
		output = []
		for tup in temp:
			for node in self.bestNodes:
				if node in tup:
					output += [tup]
					break
		return output
		#return list(itertools.combinations(set([range(0,self.n)]+[self.bestNodes]),n)) if n < self.n else self.combinations
		#print(self.permutations)
	def parseMatrix(self,matrix):
		pass
	def solve(self):
		startTime = time.time()
		cardinal = 0
		numNodes = self.n
		while numNodes >= 1:
			self.solutions = set()
			for perm in self.getCombinations(numNodes):
				if self.isClique(perm,startTime):
					self.iters += 1
					self.solutions.add(tuple(sorted(perm)))
					if cardinal == 0:
						self.iters += 3
						self.bestSolution = perm
						cardinal = len(perm)
					if self.numSolutions == len(self.solutions): #Dont need to check 0, because self.s will aklways be > 0, here
							return (self.bestSolution,(time.time()-startTime),cardinal,len(self.solutions),self.iters)
							#return (time.time()-startTime)

				if self.limitCpuTime > 0:
					if (time.time() - startTime) > self.limitCpuTime:
						#print("Times Up!")
						return (self.bestSolution,(time.time()-startTime),cardinal,len(self.solutions),self.iters)
						#return (time.time()-startTime)
			numNodes-=1
			if len(self.solutions) > 0:
				return (self.bestSolution,(time.time()-startTime),cardinal,len(self.solutions),self.iters)	
				#return (time.time()-startTime)
		return (self.bestSolution,(time.time()-startTime),cardinal,len(self.solutions),self.iters)
		#return (time.time()-startTime)
		pass
	def isClique(self,seq,startTime):
		#print(seq)
		
		for i in range(0,self.n):
			self.iters += 1
			if i not in seq:
				continue

			for j in range(i+1,self.n):
				self.iters += 1
				if j not in seq:
					continue
				self.iters += 1
				if self.matrix[i][j] == 0:
					return False
				if self.limitCpuTime > 0:
					if (time.time() - startTime) > self.limitCpuTime:
						return False
		return True


class node:
	def __init__(self):
		pass
		

import random
import graph
import graph1
import argparse
import graph2

def parseArguments():
    # Create argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument("nodes", help="Num. of Solutions.", type=int)
    # Optional arguments
    parser.add_argument("-c", "--cputime", help="CPU limit in seconds", type=float, default=0.0)
    parser.add_argument("-s", "--solutions",  help="Num. of Solutions.", type=int, default=0)
    parser.add_argument("-p", "--probability",  help="Probability of an Edge.", type=float, default=0.5)
    parser.add_argument("-g", "--graph",  help="Graph Version", type=int, default=0)
   
    # Print version
    parser.add_argument("--version", action="version", version='%(prog)s - Version 1.0')

    # Parse arguments
    args = parser.parse_args()

    return args

def generateGraph(N,p=0.5):
	output = [["" for i in range(N)] for j in range(N)]
	for i in range(0,N-1):
		for j in range(i+1,N):
			if i != j:
				if output[j][i] == "": 
					output[i][j]=1 if random.random() > p else 0
				else:
					output[i][j] = output[j][i]
	return output



def main():

	# Parse the arguments
	args = parseArguments()
	if not (args.probability >= 0 and args.probability <= 1):
		print("Probability must be between 0 and 1\nInput:"+str(args.probability))
		exit(1)
	if not (args.graph <=2 and args.graph >=0):
		print("Invalid graph version, must be 0 or 1\nInput:"+str(args.graph))
		exit(1)
	matrix = generateGraph(args.nodes,1-args.probability)
	
	
	
	graphs = [graph.Graph(matrix,args.cputime,args.solutions),graph1.Graph(matrix,args.cputime,args.solutions),graph2.Graph(matrix,args.cputime,args.solutions)]
	#grafo.loadPermutations()
	#for linha in matrix:
	#	print(linha)
	for grafo in graphs:
		print(grafo.solve())

	#gg = graph2.Graph(matrix)
	#print(gg.getCombinations(1))
	#print(list(grafo.solve()))



  
if __name__== "__main__":
  main()